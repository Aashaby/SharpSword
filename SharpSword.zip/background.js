chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "loading") {
    chrome.scripting.executeScript({
      target: { tabId: tabId, allFrames: true },
      injectImmediately: true,
      func: () => {
        const customTitle = "Sharp Sword";

        // 如果 <title> 不存在，创建它
        let titleElement = document.querySelector('title');
        if (!titleElement) {
          titleElement = document.createElement('title');
          document.head.appendChild(titleElement);
        }

        titleElement.textContent = customTitle;
        document.title = customTitle;

        // 持续覆盖，防止后续脚本修改
        setInterval(() => {
          if (document.title !== customTitle || titleElement.textContent !== customTitle) {
            titleElement.textContent = customTitle;
            document.title = customTitle;
          }
        }, 10);
      }
    });
  }
});
